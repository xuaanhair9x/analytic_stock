<?php

namespace App\Model\Bank;

use Illuminate\Database\Eloquent\Model;

class CashFlowDirectInfoYearModel extends BankInfoYearModel
{
    protected $table = 'bank_cash_flow_direct_info_year';
}
