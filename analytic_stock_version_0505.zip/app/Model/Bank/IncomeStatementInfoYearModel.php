<?php

namespace App\Model\Bank;

use Illuminate\Database\Eloquent\Model;

class IncomeStatementInfoYearModel extends BankInfoYearModel
{
    protected $table = 'bank_income_statement_info_year';
}
