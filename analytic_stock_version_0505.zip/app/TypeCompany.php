<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeCompany extends Model
{
    protected $table = 'type_company';
    public $timestamps = false;
}
