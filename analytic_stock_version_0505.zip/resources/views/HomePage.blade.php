<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

<h2>Welcome to analytic stock.</h2>
<ul class="list-group">
    <li class="list-group-item">
        <a href="list_type_company">Show list type company.</a>
    </li>
    <li class="list-group-item">
        <a href="add_type_company">Add new type company.</a>
    </li>
    <li class="list-group-item">
        <a href="list_company">Show list company.</a>
    </li>
    <li class="list-group-item">
        <a href="add_company">Add new company.</a>
    </li>
    <li class="list-group-item">
        <a href="income_statements_listing">Show Income Statement.</a>
    </li>
    <li class="list-group-item">
        <a href="add_income_statements">Add Income Statement.</a>
    </li>
    <li class="list-group-item">
        <a href="income_statements_info_year_listing">Show Income Statement Info Year.</a>
    </li>
    <li class="list-group-item">
        <a href="add_income_statements_info_year">Add Income Statement Info Year.</a>
    </li>
</ul>
