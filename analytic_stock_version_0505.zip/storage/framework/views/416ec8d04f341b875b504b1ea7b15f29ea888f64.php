<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <script>
        window.onload = function () {

            var chart = new CanvasJS.Chart("chartContainer", {
                animationEnabled: true,
                theme: "light2", // "light1", "light2", "dark1", "dark2"
                title:{
                    text: "<?php echo e($dataView['title']); ?>"
                },
                axisY: {
                    title: "Đơn vị triệu đồng"
                },
                data: [{
                    type: "column",
                    showInLegend: true,
                    legendMarkerColor: "grey",
                    legendText: "<?php echo e($dataView['legendText']); ?>",
                    dataPoints: [
                        <?php $__currentLoopData = $dataView['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        { y: <?php echo e($item->value); ?>, label: <?php echo e($item->year); ?> },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
                }]
            });
            chart.render();

        }
    </script>
</head>
<body>
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
<script src="<?php echo e(URL::asset('js/canvasjs.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/bank/Analytic/LoanCustomer.blade.php ENDPATH**/ ?>