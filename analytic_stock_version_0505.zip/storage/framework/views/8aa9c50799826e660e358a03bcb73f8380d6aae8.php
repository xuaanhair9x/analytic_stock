<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<h2> Income Statements. </h2>
<a class="btn btn-primary mb-1" href="add_income_statements" role="button">Add New Income Statements.</a>
<table class="table">
    <thead>
    <tr>
        <th scope="col">id</th>
        <th scope="col">Name</th>
        <th scope="col">Name vi</th>
        <th scope="col">parent</th>
        <th scope="col">Note</th>
        <th scope="col"></th>

    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"> <?php echo e($data['id']); ?></th>
            <td><?php echo e($data['name']); ?></td>
            <td><?php echo e($data['name_vi']); ?></td>
            <td><?php echo e($data['parent']); ?></td>
            <td><?php echo e($data['note']); ?></td>
            <td><a href="edit_income_statements/<?php echo e($data['id']); ?>">edit</a> </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/IncomeStatementsListing.blade.php ENDPATH**/ ?>