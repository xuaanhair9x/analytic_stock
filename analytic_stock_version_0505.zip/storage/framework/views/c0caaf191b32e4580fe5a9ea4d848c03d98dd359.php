<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <script>
        window.onload = function () {
            var chart = new CanvasJS.Chart("chartContainer", {
                theme:"light2",
                animationEnabled: true,
                title:{
                    text: "<?php echo e($dataView['title']); ?>"
                },
                axisY :{
                    includeZero: false,
                    title: "Tỷ lệ chi phí dự phòng",
                    suffix: "%"
                },
                toolTip: {
                    shared: "true"
                },
                legend:{
                    cursor:"pointer",
                    itemclick : toggleDataSeries
                },
                data: [
                        <?php $__currentLoopData = $dataView['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        type: "spline",
                        visible: true,
                        showInLegend: true,
                        yValueFormatString: "##.00",
                        name: "<?php echo e($key); ?>",
                        dataPoints: [
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item && $item->ratio): ?>
                            { label: "<?php echo e($year); ?>", y: <?php echo e($item->ratio); ?> },
                                <?php else: ?>
                            { label: "<?php echo e($year); ?>", y: null },
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                    },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
            });
            chart.render();

            function toggleDataSeries(e) {
                if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible ){
                    e.dataSeries.visible = false;
                } else {
                    e.dataSeries.visible = true;
                }
                chart.render();
            }

        }
    </script>
</head>
<body>
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
<script src="<?php echo e(URL::asset('js/canvasjs.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/bank/Analytic/ContingencyCostRatio.blade.php ENDPATH**/ ?>