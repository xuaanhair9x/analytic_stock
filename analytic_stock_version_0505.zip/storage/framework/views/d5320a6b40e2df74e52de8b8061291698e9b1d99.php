<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<h2>Add new info.</h2>
<form class="w-50" action= "<?php echo e(route("save_data_income_statements_info_year")); ?>" method= "post">
<?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
    <?php if(!$data['data_edit']): ?>
        <select name="company_code" class="mb-3 form-control form-control-lg">
            <?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item['code']); ?>"><?php echo e($item['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="income_statement_id" class="mb-3 form-control form-control-lg">
            <?php $__currentLoopData = $data['income_statement']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="year" class="mb-3 form-control form-control-lg">
            <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="mb-3 form-group">
            <input type="text" class="form-control" name="amount" id="inputname" aria-describedby="emailHelp" placeholder="Enter Amount">
        </div>
    <?php else: ?>
        <input type="hidden" name="isedit" value="<?php echo e($data['data_edit']['id']); ?>">
        <select name="company_code" class="mb-3 form-control form-control-lg">
            <?php $__currentLoopData = $data['company']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($data['data_edit']['company_code'] == $item['code']): ?>
                            selected
                        <?php endif; ?>
                        value="<?php echo e($item['code']); ?>"><?php echo e($item['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="income_statement_id" class="mb-3 form-control form-control-lg">
            <?php $__currentLoopData = $data['income_statement']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($data['data_edit']['income_statement_id'] == $item['id']): ?>
                            selected
                        <?php endif; ?>
                        value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="year" class="mb-3 form-control form-control-lg">
            <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($data['data_edit']['year'] == $item): ?>
                        selected
                        <?php endif; ?>
                        value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="mb-3 form-group">
            <input value="<?php echo e($data['data_edit']['amount']); ?>" type="text" class="form-control" name="amount" id="inputname" aria-describedby="emailHelp" placeholder="Enter Amount">
        </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/IncomeStatementsInfoYearEditing.blade.php ENDPATH**/ ?>