<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<h2>Add new type company.</h2>
<form action= "<?php echo e(route("addingtypecompany")); ?>" method= "post">
<?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
    <div class="form-group">
        <label for="inputcode">Code</label>
        <input type="text" class="form-control" name="code" id="inputcode" aria-describedby="emailHelp" placeholder="Enter code">
    </div>
    <div class="form-group">
        <label for="inputname">Name</label>
        <input type="text" class="form-control" name="name" id="inputname" aria-describedby="emailHelp" placeholder="Enter name">
    </div>
    <div class="form-group">
        <label for="inputnamevi">Name VI</label>
        <input type="text" class="form-control" name="namevi" id="inputnamevi" aria-describedby="emailHelp" placeholder="Enter name">
    </div>
    <div class="form-group">
        <label for="inputdescription">Description</label>
        <input type="text" class="form-control" name="description" id="inputdescription" aria-describedby="emailHelp" placeholder="Enter name">
    </div>
    <div class="form-group">
        <label for="inputdescriptionvi">Description VI</label>
        <input type="text" class="form-control" name="descriptionvi" id="inputdescriptionvi" aria-describedby="emailHelp" placeholder="Enter name">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/addtypecompany.blade.php ENDPATH**/ ?>