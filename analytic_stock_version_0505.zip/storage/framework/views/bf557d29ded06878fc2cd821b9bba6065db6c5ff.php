<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<h2> Income Statements. </h2>
<a class="btn btn-primary mb-1" href="add_income_statements_info_year" role="button">Add New Income Statements.</a>
<table class="table">
    <thead>
    <tr>
        <th scope="col">Company</th>
        <th scope="col">Income statement</th>
        <th scope="col">Year</th>
        <th scope="col">Amount</th>
        <th scope="col"></th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->company); ?></td>
            <td><?php echo e($data->income_statement); ?></td>
            <td><?php echo e($data->year); ?></td>
            <td><?php echo e($data->amount); ?></td>
            <td><a href="edit_income_statements_info_year/<?php echo e($data->id); ?>">edit</a> </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/IncomeStatementsInfoYearListing.blade.php ENDPATH**/ ?>