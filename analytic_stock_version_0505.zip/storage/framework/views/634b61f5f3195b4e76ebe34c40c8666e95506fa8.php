<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<h2>Add new info.</h2>
<form action= "<?php echo e(route("save_data_income_statements")); ?>" method= "post">
<?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
    <?php if(!$data['data_edit']): ?>
        <select name="parent" class="mb-3 form-control form-control-lg">
            <?php $__currentLoopData = $data['parent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="0">No parent</option>
                <option value="<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="form-group mb-3">
            <label for="inputname">Name</label>
            <input type="text" class="form-control" name="name" id="inputname" aria-describedby="emailHelp" placeholder="Enter name">
        </div>
        <div class="form-group mb-3">
            <label for="inputnamevi">Name VI</label>
            <input type="text" class="form-control" name="name_vi" id="inputnamevi" aria-describedby="emailHelp" placeholder="Enter name">
        </div>
        <div class="form-group mb-3">
            <label for="inputdescription">Note</label>
            <input type="text" class="form-control" name="note" id="inputdescription" aria-describedby="emailHelp" placeholder="Enter name">
        </div>
    <?php else: ?>
        <input type="hidden" name="isedit" value="<?php echo e($data['data_edit']['id']); ?>">
        <div class="form-group mb-3">
            <label for="inputname">Name</label>
            <input type="text" value="<?php echo e($data['data_edit']['name']); ?>" class="form-control" name="name" id="inputname" aria-describedby="emailHelp" placeholder="Enter name">
        </div>
        <div class="form-group mb-3">
            <label for="inputnamevi">Name VI</label>
            <input type="text" value="<?php echo e($data['data_edit']['name_vi']); ?>" class="form-control" name="name_vi" id="inputnamevi" aria-describedby="emailHelp" placeholder="Enter name">
        </div>
        <div class="form-group mb-3">
            <label for="inputdescription">Description</label>
            <input type="text" value="<?php echo e($data['data_edit']['note']); ?>" class="form-control" name="note" id="inputdescription" aria-describedby="emailHelp" placeholder="Enter name">
        </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/IncomeStatementsEditing.blade.php ENDPATH**/ ?>