<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<form action= "<?php echo e(route("save_indicator_info")); ?>" method= "post">
<?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
    <?php if($dataView['id']): ?>
        <div class="form-row">
            <input type="hidden" name="report_norm_id" value="<?php echo e($dataView['indicator']->report_norm_id); ?>">
            <input type="hidden" name="income_statement_id" value="<?php echo e($dataView['indicator']->id); ?>">
            <input type="hidden" name="company_vs_id" value="<?php echo e($dataView['company']->company_vs_id); ?>">
            <input type="hidden" name="year" value="<?php echo e($dataView['indicator_info']->year); ?>">
            <input type="hidden" name="id" value="<?php echo e($dataView['id']); ?>">
            <div class="form-group col-md-6">
                <label for="indicator">Indicator</label>
                <input type="email" class="form-control" value="<?php echo e($dataView['indicator']->name); ?>" id="indicator" disabled>
            </div>
            <div class="form-group col-md-6">
                <label for="company">Company</label>
                <input type="text" class="form-control" value="<?php echo e($dataView['company']->getName()); ?>" id="company" disabled>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-2">
                <label for="company-code">Company Code</label>
                <input type="text" name="company_code" class="form-control" value="<?php echo e($dataView['company']->getCode()); ?>" id="company-code" readonly>
            </div>
            <div class="form-group col-md-4">
                <label for="inputState">Year</label>
                <select id="inputState" required name="year" class="form-control" disabled>
                    <?php $__currentLoopData = $dataView['years']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            <?php if($dataView['indicator_info']->year==$year): ?>
                                selected
                            <?php endif; ?>
                            name="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="inputAddress">Value</label>
                <input type="text" name="value" value="<?php echo e($dataView['indicator_info']->value); ?>" required class="form-control" id="inputAddress" placeholder="1,222,222">
            </div>
        </div>
    <?php else: ?>
        <div class="form-row">
            <input type="hidden" name="report_norm_id" value="<?php echo e($dataView['indicator']->report_norm_id); ?>">
            <input type="hidden" name="income_statement_id" value="<?php echo e($dataView['indicator']->id); ?>">
            <input type="hidden" name="company_vs_id" value="<?php echo e($dataView['company']->company_vs_id); ?>">
            <div class="form-group col-md-6">
                <label for="indicator">Indicator</label>
                <input type="email" class="form-control" value="<?php echo e($dataView['indicator']->name); ?>" id="indicator" disabled>
            </div>
            <div class="form-group col-md-6">
                <label for="company">Company</label>
                <input type="text" class="form-control" value="<?php echo e($dataView['company']->getName()); ?>" id="company" disabled>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-2">
                <label for="company-code">Company Code</label>
                <input type="text" name="company_code" class="form-control" value="<?php echo e($dataView['company']->getCode()); ?>" id="company-code" readonly>
            </div>
            <div class="form-group col-md-4">
                <label for="inputState">Year</label>
                <select id="inputState" required name="year" class="form-control">
                    <?php $__currentLoopData = $dataView['years']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option name="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="inputAddress">Value</label>
                <input type="text" name="value" required class="form-control" id="inputAddress" placeholder="1,222,222">
            </div>
        </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/Bank/EditIndicatorInfo.blade.php ENDPATH**/ ?>