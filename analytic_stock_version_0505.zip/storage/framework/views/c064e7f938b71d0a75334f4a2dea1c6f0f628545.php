<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <script>
        window.onload = function () {
            var chart = new CanvasJS.Chart("chartContainer", {
                animationEnabled: true,
                theme: "light2", //"light1", "dark1", "dark2"
                title:{
                    text: "<?php echo e($dataView['title']); ?>"
                },
                axisY:{
                    interval: 10,
                    suffix: "%"
                },
                toolTip:{
                    shared: true
                },
                data:[
                        <?php $__currentLoopData = $dataView['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        type: "stackedBar100",
                        toolTipContent: "<b>{name}:</b> {y} (#percent%)",
                        showInLegend: true,
                        name: "<?php echo e($data['label']); ?>",
                        dataPoints: [
                                <?php $__currentLoopData = $data['info_year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            { y: <?php echo e($year->value); ?>, label: "<?php echo e($year->label); ?>" },
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]
                    },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
            });
            chart.render();

        }
    </script>
</head>
<body>
<div id="chartContainer" style="height: 570px; max-width: 1320px; margin: 0px auto;"></div>
<script src="<?php echo e(URL::asset('js/canvasjs.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Users/xuanhai/www/drupal8/resources/views/bank/LoanOfBankByYears.blade.php ENDPATH**/ ?>